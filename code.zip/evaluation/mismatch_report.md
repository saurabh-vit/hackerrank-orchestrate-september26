# Benchmark Mismatch Diagnostic Report

Total Evaluated Samples: 25
Full Row Matches: 3 / 25 (12.0%)
Mismatched Samples: 22 / 25

---

## request_02 (User: user_02)

**EXPECTED:**
- amount_safe_to_pay: `17229139.2`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2025-08-08:15952906.67|2025-09-07:15952906.67|2025-10-07:15952906.67`
- earliest_date_for_full_payment: `2025-09-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `17964061.314`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2025-08-08:15952906.67|2025-09-07:15952906.67|2025-10-07:15952906.67`
- earliest_date_for_full_payment: `2025-09-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `17229139.2` vs Actual `17964061.314`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_03 (User: user_03)

**EXPECTED:**
- amount_safe_to_pay: `873000`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2019-11-15:5491000`
- earliest_date_for_full_payment: `2019-11-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `952828.862`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2019-11-15:5491000`
- earliest_date_for_full_payment: `2019-11-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `873000` vs Actual `952828.862`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_04 (User: user_04)

**EXPECTED:**
- amount_safe_to_pay: `8401800`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2024-06-15:12693000`
- earliest_date_for_full_payment: `2024-06-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `10750164.684`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2024-06-15:12693000`
- earliest_date_for_full_payment: `2024-06-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `8401800` vs Actual `10750164.684`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_05 (User: user_05)

**EXPECTED:**
- amount_safe_to_pay: `737`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `0`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `737` vs Actual `0`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_06 (User: user_06)

**EXPECTED:**
- amount_safe_to_pay: `603.3`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `full_payment`
- payment_plan: `2026-01-03:620.40`
- earliest_date_for_full_payment: `2026-01-15`
- spending_changes_needed: `stop:event_476`

**ACTUAL:**
- amount_safe_to_pay: `620.4`
- affordability_status: `affordable_now`
- recommended_payment_method: `full_payment`
- payment_plan: `2026-01-03:620.40`
- earliest_date_for_full_payment: `2026-01-03`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `603.3` vs Actual `620.4`
- `affordability_status`: Expected `affordable_with_plan` vs Actual `affordable_now`
- `earliest_date_for_full_payment`: Expected `2026-01-15` vs Actual `2026-01-03`
- `spending_changes_needed`: Expected `stop:event_476` vs Actual `none`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_07 (User: user_07)

**EXPECTED:**
- amount_safe_to_pay: `87170.56`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2024-09-12:68432|2024-10-10:68432|2024-11-07:68432`
- earliest_date_for_full_payment: `2024-10-23`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `87341.730`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2024-09-12:68432|2024-10-10:68432|2024-11-07:68432`
- earliest_date_for_full_payment: `2024-10-23`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `87170.56` vs Actual `87341.730`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_08 (User: user_08)

**EXPECTED:**
- amount_safe_to_pay: `284.57`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2025-04-15:996.60`
- earliest_date_for_full_payment: `2025-04-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `833.694`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2025-05-07:996.60`
- earliest_date_for_full_payment: `2025-05-07`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `284.57` vs Actual `833.694`
- `payment_plan`: Expected `2025-04-15:996.60` vs Actual `2025-05-07:996.60`
- `earliest_date_for_full_payment`: Expected `2025-04-15` vs Actual `2025-05-07`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_10 (User: user_10)

**EXPECTED:**
- amount_safe_to_pay: `12700`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `266700`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: `2024-12-06`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `12700` vs Actual `266700`
- `earliest_date_for_full_payment`: Expected `` vs Actual `2024-12-06`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_11 (User: user_11)

**EXPECTED:**
- amount_safe_to_pay: `12510645`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `full_payment`
- payment_plan: `2025-05-03:13110000`
- earliest_date_for_full_payment: `2025-07-15`
- spending_changes_needed: `reduce_to:event_989:665950`

**ACTUAL:**
- amount_safe_to_pay: `13110000`
- affordability_status: `affordable_now`
- recommended_payment_method: `full_payment`
- payment_plan: `2025-05-03:13110000`
- earliest_date_for_full_payment: `2025-05-03`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `12510645` vs Actual `13110000`
- `affordability_status`: Expected `affordable_with_plan` vs Actual `affordable_now`
- `earliest_date_for_full_payment`: Expected `2025-07-15` vs Actual `2025-05-03`
- `spending_changes_needed`: Expected `reduce_to:event_989:665950` vs Actual `none`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_12 (User: user_12)

**EXPECTED:**
- amount_safe_to_pay: `65164`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2026-04-19:22590.19|2026-05-20:22590.19|2026-06-20:22590.19`
- earliest_date_for_full_payment: `2026-04-05`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `58217.670`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2026-04-19:22590.19|2026-05-20:22590.19|2026-06-20:22590.19`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `stop:event_1016|reduce_to:event_1017:511.28|reduce_to:event_1054:1072.50`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `65164` vs Actual `58217.670`
- `earliest_date_for_full_payment`: Expected `2026-04-05` vs Actual ``
- `spending_changes_needed`: Expected `none` vs Actual `stop:event_1016|reduce_to:event_1017:511.28|reduce_to:event_1054:1072.50`

**ROOT CAUSE:**
Variable spending interval and anchor date alignment difference.

---

## request_13 (User: user_13)

**EXPECTED:**
- amount_safe_to_pay: `433.4`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2024-05-15:941.60`
- earliest_date_for_full_payment: `2024-05-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `941.6`
- affordability_status: `affordable_now`
- recommended_payment_method: `full_payment`
- payment_plan: `2024-03-07:941.60`
- earliest_date_for_full_payment: `2024-03-07`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `433.4` vs Actual `941.6`
- `affordability_status`: Expected `affordable_later` vs Actual `affordable_now`
- `recommended_payment_method`: Expected `wait` vs Actual `full_payment`
- `payment_plan`: Expected `2024-05-15:941.60` vs Actual `2024-03-07:941.60`
- `earliest_date_for_full_payment`: Expected `2024-05-15` vs Actual `2024-03-07`

**ROOT CAUSE:**
Underestimation of recurring essential living expenses between request_date and next salary date leads to overestimating headroom.

---

## request_14 (User: user_14)

**EXPECTED:**
- amount_safe_to_pay: `597.74`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `0`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `597.74` vs Actual `0`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_15 (User: user_15)

**EXPECTED:**
- amount_safe_to_pay: `83.05`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `6.680`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `83.05` vs Actual `6.680`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_17 (User: user_17)

**EXPECTED:**
- amount_safe_to_pay: `243849.58`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2026-03-01:95194.67|2026-03-31:95194.67|2026-04-30:95194.67`
- earliest_date_for_full_payment: `2026-03-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `230115.398`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2026-03-01:95194.67|2026-03-31:95194.67|2026-04-30:95194.67`
- earliest_date_for_full_payment: `2026-03-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `243849.58` vs Actual `230115.398`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_18 (User: user_18)

**EXPECTED:**
- amount_safe_to_pay: `462`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2026-09-15:3246.10`
- earliest_date_for_full_payment: `2026-09-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `559.050`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2026-09-15:3246.10`
- earliest_date_for_full_payment: `2026-09-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `462` vs Actual `559.050`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_19 (User: user_19)

**EXPECTED:**
- amount_safe_to_pay: `28820`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `partial_payment`
- payment_plan: `2024-09-04:28820|2024-09-15:10840`
- earliest_date_for_full_payment: `2024-09-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `30665.28`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `partial_payment`
- payment_plan: `2024-09-04:30665.28|2024-09-15:8994.72`
- earliest_date_for_full_payment: `2024-09-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `28820` vs Actual `30665.28`
- `payment_plan`: Expected `2024-09-04:28820|2024-09-15:10840` vs Actual `2024-09-04:30665.28|2024-09-15:8994.72`

**ROOT CAUSE:**
Safe amount today was computed as 30665.28 vs expected 28820.00 due to minor variable expense averaging differences.

---

## request_20 (User: user_20)

**EXPECTED:**
- amount_safe_to_pay: `5400`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `8322.840`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `5400` vs Actual `8322.840`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_21 (User: user_21)

**EXPECTED:**
- amount_safe_to_pay: `1543.35`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `full_payment`
- payment_plan: `2026-04-03:1574.40`
- earliest_date_for_full_payment: `2026-04-15`
- spending_changes_needed: `stop:event_1815|reduce_to:event_1816:23.50`

**ACTUAL:**
- amount_safe_to_pay: `1574.4`
- affordability_status: `affordable_now`
- recommended_payment_method: `full_payment`
- payment_plan: `2026-04-03:1574.40`
- earliest_date_for_full_payment: `2026-04-03`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `1543.35` vs Actual `1574.4`
- `affordability_status`: Expected `affordable_with_plan` vs Actual `affordable_now`
- `earliest_date_for_full_payment`: Expected `2026-04-15` vs Actual `2026-04-03`
- `spending_changes_needed`: Expected `stop:event_1815|reduce_to:event_1816:23.50` vs Actual `none`

**ROOT CAUSE:**
Safe amount today without spending changes was overestimated as 1574.40 vs expected 1543.35, cascading into missing required spending changes.

---

## request_22 (User: user_22)

**EXPECTED:**
- amount_safe_to_pay: `475.46`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2024-12-08:253.59|2025-01-05:253.59|2025-02-02:253.59`
- earliest_date_for_full_payment: `2025-01-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `467.064`
- affordability_status: `affordable_with_plan`
- recommended_payment_method: `installments`
- payment_plan: `2024-12-08:253.59|2025-01-05:253.59|2025-02-02:253.59`
- earliest_date_for_full_payment: `2025-01-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `475.46` vs Actual `467.064`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_23 (User: user_23)

**EXPECTED:**
- amount_safe_to_pay: `9152`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2025-07-15:38016`
- earliest_date_for_full_payment: `2025-07-15`
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `8824.146`
- affordability_status: `affordable_later`
- recommended_payment_method: `wait`
- payment_plan: `2025-07-15:38016`
- earliest_date_for_full_payment: `2025-07-15`
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `9152` vs Actual `8824.146`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_24 (User: user_24)

**EXPECTED:**
- amount_safe_to_pay: `13420`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `13397.160`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `13420` vs Actual `13397.160`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---

## request_25 (User: user_25)

**EXPECTED:**
- amount_safe_to_pay: `1425000`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**ACTUAL:**
- amount_safe_to_pay: `333358.674`
- affordability_status: `not_affordable`
- recommended_payment_method: `not_recommended`
- payment_plan: `none`
- earliest_date_for_full_payment: ``
- spending_changes_needed: `none`

**FIELD DIFFERENCES:**
- `amount_safe_to_pay`: Expected `1425000` vs Actual `333358.674`

**ROOT CAUSE:**
Minor variance in variable expense stream interval estimation (weekly/bi-weekly vs exact day-count) causes headroom trough to differ slightly.

---
